
export interface Venue {
    id:number | undefined ;
    name:string | undefined;
    address:string | undefined;
    url:string | undefined;
    alt:string | undefined;
    }
