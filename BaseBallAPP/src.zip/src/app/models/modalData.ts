export interface ModalData {
  name:string;
  color:string;

}