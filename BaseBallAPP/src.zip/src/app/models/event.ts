export interface Evento {

    id:number | undefined ;
    name:string | undefined;
    address:string | undefined;
    applicantName:string | undefined; 
    applicantAddress:string | undefined;
    applicantMob:string| undefined; 
    aaplicantEmail:string| undefined; 
    fromDate:string| undefined;
    endDate:string| undefined;
    teamID:number| undefined;
    venueID:number| undefined; 
}
