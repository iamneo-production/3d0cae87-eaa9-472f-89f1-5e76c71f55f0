export interface Player {
    id:number ;
    playername:string;
    country:string;
}
