export interface User {
    id:number ;
    userName:string;
    roles:string ;
    password:string;
}
