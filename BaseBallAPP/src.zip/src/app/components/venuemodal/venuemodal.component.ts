import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-venuemodal',
  templateUrl: './venuemodal.component.html',
  styleUrls: ['./venuemodal.component.css']
})
export class VenuemodalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
