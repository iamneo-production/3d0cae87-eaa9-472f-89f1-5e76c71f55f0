import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ui-grid',
  templateUrl: './ui-grid.component.html',
  styleUrls: ['./ui-grid.component.css']
})
export class UiGridComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
